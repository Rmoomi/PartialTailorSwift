package com.example.signup_sqlite;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class admin extends AppCompatActivity {

    private EditText firstName, lastName, email, password, confirmPassword;
    private Button authButton;
    private TextView switchAuthText;
    private LinearLayout signupContainer;
    private DatabaseHelper dbHelper;
    private boolean isLoginMode = true; // Default to login mode

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        dbHelper = new DatabaseHelper(this);

        // Initialize Views
        firstName = findViewById(R.id.firstname);
        lastName = findViewById(R.id.lastname);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirm_password);
        authButton = findViewById(R.id.auth_button);
        switchAuthText = findViewById(R.id.switch_auth_text);
        signupContainer = findViewById(R.id.signup_container);

        updateUI(); // Set initial UI state

        // Handle authentication button click
        authButton.setOnClickListener(v -> {
            if (isLoginMode) {
                loginUser();
            } else {
                signupUser();
            }
        });

        // Toggle between Login and Signup
        switchAuthText.setOnClickListener(v -> {
            isLoginMode = !isLoginMode;
            updateUI();
        });
    }

    private void updateUI() {
        if (isLoginMode) {
            firstName.setVisibility(View.GONE);
            lastName.setVisibility(View.GONE);
            confirmPassword.setVisibility(View.GONE);
            authButton.setText("Log In");
            switchAuthText.setText("Don't have an account? Sign up");
        } else {
            firstName.setVisibility(View.VISIBLE);
            lastName.setVisibility(View.VISIBLE);
            confirmPassword.setVisibility(View.VISIBLE);
            authButton.setText("Sign Up");
            switchAuthText.setText("Already have an account? Log in");
        }
    }

    private void loginUser() {
        String emailAddress = email.getText().toString().trim();
        String pass = password.getText().toString().trim();

        if (!emailAddress.isEmpty() && !pass.isEmpty()) {
            if (dbHelper.checkUser(emailAddress, pass)) {
                Toast.makeText(admin.this, "Login successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(admin.this, dashboard.class));
                finish();
            } else {
                Toast.makeText(admin.this, "Invalid email or password.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(admin.this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
        }
    }

    private void signupUser() {
        String first = firstName.getText().toString().trim();
        String last = lastName.getText().toString().trim();
        String emailAddress = email.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String confirmPass = confirmPassword.getText().toString().trim();

        if (!first.isEmpty() && !last.isEmpty() && !emailAddress.isEmpty() && !pass.isEmpty()) {
            if (pass.equals(confirmPass)) {
                if (dbHelper.insertUser(first, last, emailAddress, pass)) {
                    Toast.makeText(admin.this, "Sign up successful!", Toast.LENGTH_SHORT).show();
                    isLoginMode = true; // Switch to login mode
                    updateUI();
                } else {
                    Toast.makeText(admin.this, "Sign up failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(admin.this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(admin.this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
        }
    }
}
